# Gulp Template 2

[Show the project](https://tim2015web.github.io//)

Layout. Gulp Template 2

---

[Показать проект](https://tim2015web.github.io//)

Вёрстка. Gulp Template 2

---

<img src="screenshot.jpg" title="Screenshot" alt="HTML"/>